// 自动生成的登录信息文件
// 生成时间: 1579607.781

window.LoginInfo = {
  "area_id": 43,
  "uid": 1646709,
  "server_name": "进贤门",
  "server_type": 3,
  "roleid": "23388977",
  "area_name": "广东2区",
  "block_urs": "ch****02@163.com",
  "user_icon": "2",
  "user_msg_num": 4,
  "safe_code": "mtLgdgK2",
  "user_level": "0",
  "user_roles": {
    "23157600": {
      "color": "0",
      "roleid": "23157600",
      "racename": "人",
      "grade": 29,
      "race": "1",
      "nickname": "热血青年_华",
      "icon": 1
    },
    "23157820": {
      "color": "0",
      "roleid": "23157820",
      "racename": "人",
      "grade": 51,
      "race": "1",
      "nickname": "废青辉",
      "icon": 2
    },
    "23388977": {
      "color": "0",
      "roleid": "23388977",
      "racename": "人",
      "grade": 0,
      "race": "1",
      "nickname": "≌崔承煜ㄤ3",
      "icon": 2
    },
    "23389376": {
      "color": "0",
      "roleid": "23389376",
      "racename": "人",
      "grade": 8,
      "race": "1",
      "nickname": "ю朱迎梦ㄕ3",
      "icon": 2
    },
    "23389404": {
      "color": "0",
      "roleid": "23389404",
      "racename": "人",
      "grade": 0,
      "race": "1",
      "nickname": "％湛к映秋3",
      "icon": 2
    },
    "23389467": {
      "color": "0",
      "roleid": "23389467",
      "racename": "人",
      "grade": 0,
      "race": "1",
      "nickname": "阚γ映秋ㄎ3",
      "icon": 2
    }
  },
  "is_server_open_wallet": true,
  "urs": "chenguohuacgh002@163.com",
  "login": true,
  "nickname": "≌崔承煜ㄤ3",
  "serverid": 77,
  "serversn": 420,
  "pass_mb_check": 1
};
