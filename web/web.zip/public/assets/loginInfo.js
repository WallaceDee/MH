// 自动生成的登录信息文件
// 生成时间: 662266.281

window.LoginInfo = {
  "area_id": 43,
  "uid": 1635401,
  "server_name": "进贤门",
  "server_type": 3,
  "roleid": "23387570",
  "area_name": "广东2区",
  "block_urs": "ch****01@163.com",
  "user_icon": "2",
  "user_msg_num": 5,
  "safe_code": "8CmY4gya",
  "user_level": "0",
  "user_roles": {
    "23157594": {
      "color": "0",
      "roleid": "23157594",
      "racename": "人",
      "grade": 35,
      "race": "1",
      "nickname": "热血青年_辉",
      "icon": 1
    },
    "23157818": {
      "color": "0",
      "roleid": "23157818",
      "racename": "人",
      "grade": 50,
      "race": "1",
      "nickname": "废青华",
      "icon": 2
    },
    "23387570": {
      "color": "0",
      "roleid": "23387570",
      "racename": "人",
      "grade": 0,
      "race": "1",
      "nickname": "☆柏μ纬灏3",
      "icon": 2
    },
    "23387585": {
      "color": "0",
      "roleid": "23387585",
      "racename": "人",
      "grade": 0,
      "race": "1",
      "nickname": "Ⅱ商〓奔3",
      "icon": 2
    },
    "23388090": {
      "color": "0",
      "roleid": "23388090",
      "racename": "人",
      "grade": 0,
      "race": "1",
      "nickname": "℃敖四红≈3",
      "icon": 2
    },
    "23388209": {
      "color": "0",
      "roleid": "23388209",
      "racename": "人",
      "grade": 0,
      "race": "1",
      "nickname": "ǚ阚冰彤∫3",
      "icon": 2
    }
  },
  "is_server_open_wallet": true,
  "urs": "chenguohuacgh001@163.com",
  "login": true,
  "nickname": "☆柏μ纬灏3",
  "serverid": 77,
  "serversn": 420,
  "pass_mb_check": 1
};
