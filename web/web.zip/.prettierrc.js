module.exports = {
  semi: false,
  singleQuote: true,
  trailingComma: 'none',
  endOfLine: 'auto',
  printWidth: 100,
  tabWidth: 2
} 